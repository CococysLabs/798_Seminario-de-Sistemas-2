#!/usr/bin/env bash
set -euo pipefail

echo "== Versiones =="
python --version
dbt --version

echo
echo "== Variables =="
: "${GCP_PROJECT_ID:?Falta GCP_PROJECT_ID}"
: "${DBT_DATASET_PREFIX:?Falta DBT_DATASET_PREFIX}"
: "${GOOGLE_APPLICATION_CREDENTIALS:?Falta GOOGLE_APPLICATION_CREDENTIALS}"

test -f "$GOOGLE_APPLICATION_CREDENTIALS"

echo
echo "== dbt debug =="
cd dbt
dbt debug

echo
echo "Ambiente valido."

