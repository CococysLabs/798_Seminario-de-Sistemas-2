#!/usr/bin/env bash
set -euo pipefail

mkdir -p "$HOME/.dbt" "$HOME/.gcp"

if [[ -f "dbt/profiles.yml" ]]; then
  cp dbt/profiles.yml "$HOME/.dbt/profiles.yml"
fi

if [[ -n "${GCP_SERVICE_ACCOUNT_KEY_JSON:-}" ]]; then
  printf '%s' "$GCP_SERVICE_ACCOUNT_KEY_JSON" > "$HOME/.gcp/ss2-dbt-workshop-sa.json"
  chmod 600 "$HOME/.gcp/ss2-dbt-workshop-sa.json"
  export GOOGLE_APPLICATION_CREDENTIALS="$HOME/.gcp/ss2-dbt-workshop-sa.json"
  if ! grep -q "ss2-dbt-workshop-sa.json" "$HOME/.bashrc"; then
    {
      echo ''
      echo '# SS2 dbt workshop'
      echo 'export GOOGLE_APPLICATION_CREDENTIALS="$HOME/.gcp/ss2-dbt-workshop-sa.json"'
    } >> "$HOME/.bashrc"
  fi
fi

if [[ -z "${DBT_DATASET_PREFIX:-}" ]]; then
  export DBT_DATASET_PREFIX="${CODESPACE_NAME:-grupo_demo}"
  if ! grep -q "DBT_DATASET_PREFIX" "$HOME/.bashrc"; then
    echo 'export DBT_DATASET_PREFIX="${CODESPACE_NAME:-grupo_demo}"' >> "$HOME/.bashrc"
  fi
fi

cat <<'MSG'
Codespace preparado.

Variables esperadas:
- GCP_PROJECT_ID
- DBT_DATASET_PREFIX
- GOOGLE_APPLICATION_CREDENTIALS

Siguiente paso:
  cd dbt
  dbt debug
MSG

